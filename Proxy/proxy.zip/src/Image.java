interface Image {
    public void displayImage();
    void showData();
}