public class Hyppy {
    
    private final double pituus;

    public Hyppy(double pituus) {
        
        this.pituus = pituus;
    }

    public double getPituus() {
        return pituus;
    }
    
}