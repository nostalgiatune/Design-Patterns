public interface Visitable {
    void accept(CharacterVisitor visitor);
}