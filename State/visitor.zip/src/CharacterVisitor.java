public interface CharacterVisitor {
    void visit(Pokemon pokemon);
    void visit(Digimon digimon);
}