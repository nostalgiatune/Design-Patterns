public interface DigimonState {
    public void attack();
    public void giveBonus(int bonus);
    public int getBonus();
}