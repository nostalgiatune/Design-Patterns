public interface Sort<T> {
    
    public void sort(T[] array);
}