package com.tuoppi.builder.hamburger;

public class Beef {
    
    private final String name;

    public Beef(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
}