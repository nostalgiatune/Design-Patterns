package com.tuoppi.builder.hamburger;

public class Bun {
    
    private final String name;

    public Bun(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
}