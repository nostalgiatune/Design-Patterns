package com.tuoppi.builder.hamburger;

public class Salad {
    
    private final String name;

    public Salad(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
}