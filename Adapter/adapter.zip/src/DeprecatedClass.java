public class DeprecatedClass {
    
    protected final String nimi;

    public DeprecatedClass(String nimi) {
        this.nimi = nimi;
    }
    
    public String annaNimi() {
        return nimi;
    }
}