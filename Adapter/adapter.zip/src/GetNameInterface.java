public interface GetNameInterface {
    String getName();
}