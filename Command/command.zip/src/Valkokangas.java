public class Valkokangas {
    
    public void ylos() {
        System.out.println("Valkokangas ylös");
    }
    
    public void alas() {
        System.out.println("Valkokangas alas");
    }
}