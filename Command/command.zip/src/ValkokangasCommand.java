@FunctionalInterface
public interface ValkokangasCommand {
    
    void execute(Valkokangas valkokangas);
}