public class RawMaterialGoods implements Goods {
    
}