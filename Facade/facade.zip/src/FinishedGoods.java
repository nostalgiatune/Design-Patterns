public class FinishedGoods implements Goods {
    
}