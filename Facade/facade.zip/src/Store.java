
public interface Store {
    
    public Goods getGoods();
}
