public interface Goods {
    
}