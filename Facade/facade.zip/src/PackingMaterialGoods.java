public class PackingMaterialGoods implements Goods {
    
}